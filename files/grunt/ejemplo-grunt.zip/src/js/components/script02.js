(function() {
    var message = 'script 02 tambien ok!!';

    console.log(message);
})();