(function() {
    var message = 'script 01 ok!!';

    console.log(message);
})();