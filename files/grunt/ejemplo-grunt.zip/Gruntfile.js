module.exports = function(grunt) {

    // 1. Toda la configuración va aqui
    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),

        // 2. Configuramos las diferentes tareas.
        sass: {
            options: {
                sourcemap: 'none',
                style: 'expanded'
            },
            dist: {
                files: {
                    'dist/css/main.css': 'src/scss/main.scss'
                }
            }
        }

    });

    // 3. Indicamos a Grunt los plugins que utilizaremos
    grunt.loadNpmTasks('grunt-contrib-sass');

    // 4. Definimos los distintos tasks que se ejecutaran desde la terminal
    grunt.registerTask('default', [
        'sass'
    ]);

};